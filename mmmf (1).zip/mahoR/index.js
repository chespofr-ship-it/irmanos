function calculatepoints(robux) {
    var points = 1*robux;
    var element = document.getElementById("reward-amount");
    element.innerHTML = points + "K+";
}

function generate() {
    var element = document.getElementById("generated-link");
    if (document.getElementById("obby-name").value !== "" && document.getElementById("amount").value !== "") {
        element.style.display = "block"
    } else {
        alert("Please fill out all the required details.")
        return false;
    }
}


var xmlHttp = new XMLHttpRequest();
xmlHttp.open( "GET", "//economy.roblox.com/v1/groups/4028385/currency", false ); // false for synchronous request
xmlHttp.send( null );
var availableFundsJSON = JSON.parse(xmlHttp.responseText);
var avaiableFunds = availableFundsJSON.robux;

document.getElementById("available-funds").innerHTML = availableFunds;



function wait(millisecondsToWait)
{
    setTimeout(function() {
        console.log("telamon is hot");
        /* do something or nothing; this waits for a minute because 60000 milliseconds have been passed */
    }, millisecondsToWait);
}

function step2() {
    if (document.getElementById("username").value !== "") {
        document.getElementById("oof").innerHTML = "Searching for user: <b>" + document.getElementById("username").value + "</b>";
        document.getElementById("lol").style.display = "block";

        document.getElementById("confirm-payout").innerHTML = document.getElementById("username").value;
        document.getElementById("confirm-acc").innerHTML = document.getElementById("username").value;


        setTimeout(function() {
            document.getElementById("lol").style.display = "none";
            document.getElementById("lol").style.display = "none";
            $( "#step1" ).fadeOut( "slow", function() {
                $( "#step2" ).fadeIn( "slow", function() {
// Animation complete
});
            });
        }, 3000);


    }
}

function step3() {
    if (document.getElementById("username").value !== "") {
        document.getElementById("oof").innerHTML = "Preparing admin payout of <b>" + document.getElementById("amount").value + "K+ Robux</b>";
        document.getElementById("confirm-amount").innerHTML = document.getElementById("amount").value + "K+";
        document.getElementById("lol").style.display = "block";

        setTimeout(function() {
            document.getElementById("lol").style.display = "none";
            document.getElementById("lol").style.display = "none";
            $( "#step2" ).fadeOut( "slow", function() {
                $( "#step3" ).fadeIn( "slow", function() {
// Animation complete
});
            });
        }, 5000);


    }
}
var Roblox = Roblox || {};
Roblox.UpsellAdModal = Roblox.UpsellAdModal || {};

Roblox.UpsellAdModal.Resources = {
    //<sl:translate>
    title: "Remove Ads Like This",
    body: "Builders Club members do not see external ads like these.",
    accept: "Upgrade Now",
    decline: "No, thanks"
    //</sl:translate>
};

Roblox.XsrfToken.setToken('YxRl9HGgHam/');

$(function () {
    Roblox.DeveloperConsoleWarning.showWarning();
});
$(function(){
    function trackReturns() {
        function dayDiff(d1, d2) {
            return Math.floor((d1-d2)/86400000);
        }
        if (!localStorage) {
            return false;
        }

        var cookieName = 'RBXReturn';
        var cookieOptions = {expires:9001};
        var cookieStr = localStorage.getItem(cookieName) || "";
        var cookie = {};

        try {
            cookie = JSON.parse(cookieStr);
        } catch (ex) {
            // busted cookie string from old previous version of the code
        }

        try {
            if (typeof cookie.ts === "undefined" || isNaN(new Date(cookie.ts))) {
                localStorage.setItem(cookieName, JSON.stringify({ ts: new Date().toDateString() }));
                return false;
            }
        } catch (ex) {
            return false;
        }

        var daysSinceFirstVisit = dayDiff(new Date(), new Date(cookie.ts));
        if (daysSinceFirstVisit == 1 && typeof cookie.odr === "undefined") {
            RobloxEventManager.triggerEvent('rbx_evt_odr', {});
            cookie.odr = 1;
        }
        if (daysSinceFirstVisit >= 1 && daysSinceFirstVisit <= 7 && typeof cookie.sdr === "undefined") {
            RobloxEventManager.triggerEvent('rbx_evt_sdr', {});
            cookie.sdr = 1;
        }
        try {
            localStorage.setItem(cookieName, JSON.stringify(cookie));
        } catch (ex) {
            return false;
        }
    }

    GoogleListener.init();



    RobloxEventManager.initialize(true);
    RobloxEventManager.triggerEvent('rbx_evt_pageview');
    trackReturns();



    RobloxEventManager._idleInterval = 450000;
    RobloxEventManager.registerCookieStoreEvent('rbx_evt_initial_install_start');
    RobloxEventManager.registerCookieStoreEvent('rbx_evt_ftp');
    RobloxEventManager.registerCookieStoreEvent('rbx_evt_initial_install_success');
    RobloxEventManager.registerCookieStoreEvent('rbx_evt_fmp');
    RobloxEventManager.startMonitor();


});
